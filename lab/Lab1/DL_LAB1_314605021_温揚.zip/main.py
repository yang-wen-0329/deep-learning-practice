import numpy as np
import matplotlib.pyplot as plt


# functions

def generate_linear(n=100):
    pts = np.random.uniform(0, 1, (n, 2))
    inputs = []
    labels = []

    for pt in pts:
        inputs.append([pt[0], pt[1]])
        if pt[0] > pt[1]:
            labels.append(0)
        else:
            labels.append(1)

    return np.array(inputs), np.array(labels).reshape(n, 1)

def generate_XOR_easy():
    inputs = []
    labels = []

    for i in range(11):
        inputs.append([0.1 * i, 0.1 * i])
        labels.append(0)

        if 0.1 * i == 0.5:
            continue

        inputs.append([0.1 * i, 1 - 0.1 * i])
        labels.append(1)

    return np.array(inputs), np.array(labels).reshape(21, 1)

def show_result(x, y, pred_y):
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.title('Ground truth', fontsize=18)
    for i in range(x.shape[0]):
        if y[i] == 0:
            plt.plot(x[i][0], x[i][1], 'ro')
        else:
            plt.plot(x[i][0], x[i][1], 'bo')

    plt.subplot(1, 2, 2)
    plt.title('Predict result', fontsize=18)
    for i in range(x.shape[0]):
        if pred_y[i] == 0:
            plt.plot(x[i][0], x[i][1], 'ro')
        else:
            plt.plot(x[i][0], x[i][1], 'bo')
    plt.tight_layout()
    plt.savefig("result.png")
    plt.close()

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

def derivative_sigmoid(x): ## input is a sigmoid output
    return x * (1.0 - x)

def mse_loss(y_true, y_pred): ## default simple setting
    return np.mean((y_true - y_pred) ** 2)

def compute_accuracy(y_true, y_pred):
    pred_label = (y_pred >= 0.5).astype(int)
    return np.mean(pred_label == y_true) * 100

def plot_loss_curve(loss_history):
    plt.figure()
    plt.plot(loss_history)
    plt.title("Learning Curve")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.savefig("learning_curve.png")
    plt.close()

# neural network
class NeuralNetwork:
    def __init__(self, input_size, hidden1_size, hidden2_size, output_size, lr=0.1):
        self.lr = lr

        self.W1 = np.random.randn(input_size, hidden1_size)
        self.W2 = np.random.randn(hidden1_size, hidden2_size)
        self.W3 = np.random.randn(hidden2_size, output_size)

    def forward(self, X):
        self.X = X

        self.z1_in = np.dot(self.X, self.W1)
        self.z1 = sigmoid(self.z1_in)

        self.z2_in = np.dot(self.z1, self.W2)
        self.z2 = sigmoid(self.z2_in)

        self.z3_in = np.dot(self.z2, self.W3)
        self.y_hat = sigmoid(self.z3_in)

        return self.y_hat

    # without activation function

    # def forward(self, X):
    #     self.X = X

    #     self.z1_in = np.dot(self.X, self.W1)
    #     self.z1 = self.z1_in

    #     self.z2_in = np.dot(self.z1, self.W2)
    #     self.z2 = self.z2_in

    #     self.z3_in = np.dot(self.z2, self.W3)
    #     self.y_hat = self.z3_in

    #     return self.y_hat

    def backward(self, y_true):
        m = y_true.shape[0]

        error = self.y_hat - y_true
        delta3 = error * derivative_sigmoid(self.y_hat)

        dW3 = np.dot(self.z2.T, delta3) / m

        delta2 = np.dot(delta3, self.W3.T) * derivative_sigmoid(self.z2)
        dW2 = np.dot(self.z1.T, delta2) / m

        delta1 = np.dot(delta2, self.W2.T) * derivative_sigmoid(self.z1)
        dW1 = np.dot(self.X.T, delta1) / m

        self.W3 -= self.lr * dW3
        self.W2 -= self.lr * dW2
        self.W1 -= self.lr * dW1

    # without activation function

    # def backward(self, y_true):
    #     m = y_true.shape[0]

    #     error = self.y_hat - y_true
    #     delta3 = error

    #     dW3 = np.dot(self.z2.T, delta3) / m

    #     delta2 = np.dot(delta3, self.W3.T)
    #     dW2 = np.dot(self.z1.T, delta2) / m

    #     delta1 = np.dot(delta2, self.W2.T)
    #     dW1 = np.dot(self.X.T, delta1) / m

    #     self.W3 -= self.lr * dW3
    #     self.W2 -= self.lr * dW2
    #     self.W1 -= self.lr * dW1

    def train(self, X, y, epochs=100000, print_interval=5000):
        loss_history = []

        for epoch in range(epochs):
            y_pred = self.forward(X)
            loss = mse_loss(y, y_pred)
            loss_history.append(loss)

            self.backward(y)

            if epoch % print_interval == 0:
                print(f"epoch {epoch:5d} loss : {loss}")

        return loss_history

    def predict(self, X):
        y_pred = self.forward(X)
        pred_label = (y_pred >= 0.5).astype(int)
        return y_pred, pred_label

if __name__ == "__main__":
    np.random.seed(42)

    X, y = generate_linear(n=100)
    # X, y = generate_XOR_easy()

    model = NeuralNetwork(
        input_size=2,
        hidden1_size=4,
        hidden2_size=4,
        output_size=1,
        lr=0.1
    )

    loss_history = model.train(X, y, epochs=100000, print_interval=5000)

    y_pred_prob, y_pred_label = model.predict(X)
    acc = compute_accuracy(y, y_pred_prob)
    final_loss = mse_loss(y, y_pred_prob)

    for i in range(len(X)):
        print(f"Iter{i:2d} |    Ground truth: {float(y[i, 0])} |    prediction: {float(y_pred_prob[i, 0]):.5f} |")

    print(f"loss={final_loss:.5f} accuracy={acc:.2f}%")

    show_result(X, y, y_pred_label)
    plot_loss_curve(loss_history)
